<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Amarelo" tilewidth="8" tileheight="8" tilecount="88" columns="8">
 <image source="C:/Users/Student/Downloads/ruins/tiles.png" width="64" height="88"/>
</tileset>
