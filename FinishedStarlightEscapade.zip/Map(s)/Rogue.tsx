<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Rogue" tilewidth="50" tileheight="37" tilecount="120" columns="10">
 <image source="C:/Users/Student/Downloads/Fullmain.png" width="500" height="444"/>
</tileset>
