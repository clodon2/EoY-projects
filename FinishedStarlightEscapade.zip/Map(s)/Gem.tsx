<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Gem" tilewidth="64" tileheight="64" tilecount="6" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="64" height="64" source="../Sprites/Gem/download (1).png"/>
  <animation>
   <frame tileid="0" duration="400"/>
   <frame tileid="1" duration="400"/>
   <frame tileid="2" duration="400"/>
   <frame tileid="3" duration="400"/>
   <frame tileid="4" duration="400"/>
   <frame tileid="5" duration="400"/>
  </animation>
 </tile>
 <tile id="1">
  <image width="64" height="64" source="../Sprites/Gem/tile117.png"/>
 </tile>
 <tile id="2">
  <image width="64" height="64" source="../Sprites/Gem/tile118.png"/>
 </tile>
 <tile id="3">
  <image width="64" height="64" source="../Sprites/Gem/tile119.png"/>
 </tile>
 <tile id="4">
  <image width="64" height="64" source="../Sprites/Gem/tile120.png"/>
 </tile>
 <tile id="5">
  <image width="64" height="64" source="../Sprites/Gem/tile121.png"/>
 </tile>
</tileset>
