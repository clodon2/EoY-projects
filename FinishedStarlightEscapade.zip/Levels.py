def setup2(self):
        # Setup the Cameras
        self.camera = arc.Camera(self.width, self.height)
        self.gui_camera = arc.Camera(self.width, self.height)
        # Map name
        map_name = "./Map(s)/Map2.tmx"
        # Layer Specific Options for the Tilemap
        layer_options = {
        LAYER_NAME_ENEMY: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_ENEMYTURN: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_COLLECTABLE: {
        "use_spatial_hash": False,
        },
        LAYER_NAME_PLATFORMS: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_TERRAIN: {
        "use_spatial_hash": True,
        },
        LAYER_NAME_FOLIAGE: {
        "use_spatial_hash": True
        },
        LAYER_NAME_ANIMATED: {
        "use_spatial_hash": False
        },
        LAYER_NAME_ADDBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_CAVEBACKGROUND: {
        "use_spatial_hash": True
        },
        LAYER_NAME_BACKGROUND: {
        "use_spatial_hash": True
        }
        }
        # Load in TileMap
        print("Loading Tile Map")
        self.tile_map = arc.load_tilemap(map_name, TILE_SCALING, layer_options)
        print("Done loading Tile Map")
        self.scene = arc.Scene.from_tilemap(self.tile_map)
        self.end_of_map = self.tile_map.width * GRID_PIXEL_SIZE

        # Set up the player, specifically placing it at these coordinates.
        self.player_sprite = Player()
        self.player_sprite.center_x = (self.tile_map.tile_width * TILE_SCALING * PLAYER_START_X)
        self.player_sprite.center_y = (self.tile_map.tile_height * TILE_SCALING * PLAYER_START_Y)
        self.scene.add_sprite(LAYER_NAME_PLAYER, self.player_sprite)

        # Sword Hitbox Setup
        self.hitter = SwordHitbox()
        self.hitter.center_x = self.player_sprite.center_x + 37
        self.hitter.center_y = self.player_sprite.center_y + 13
        self.scene.add_sprite(LAYER_NAME_PLAYER, self.hitter)
        self.hitter.alpha = 0

        # Set up Gems, add to scene
        self.gem_list = arc.SpriteList()

        # Set up gem icon
        self.gemicon_sprite = GemIcon()
        self.gemicon_sprite.center_x = 30
        self.gemicon_sprite.center_y = 620

        # Set up Healthbar
        self.healthbar_sprite = HealthBar()
        self.healthbar_sprite.center_x = 160
        self.healthbar_sprite.center_y = 45
        self.healthbar_sprite.filltexturecenterx = self.healthbar_sprite.center_x + 36
        self.healthbar_sprite.filltexturecentery = self.healthbar_sprite.center_y - 2

        # Set up Manabar
        self.manabar_sprite = Manabar()
        self.manabar_sprite.center_x = 135
        self.manabar_sprite.center_y = 80
        self.manabar_sprite.filltexture.center_x = self.manabar_sprite.center_x - 31
        self.manabar_sprite.filltexture.center_y = self.manabar_sprite.center_y + 2
        self.manabar_sprite.filltexture2.center_x = self.manabar_sprite.center_x + 31
        self.manabar_sprite.filltexture2.center_y = self.manabar_sprite.center_y + 2

        # Set up enemies, add to scene
        # Set up enemies
        self.hound1 = DarkHound()
        self.hound1.center_x = (self.tile_map.tile_width * TILE_SCALING * 25)
        self.hound1.center_y = (self.tile_map.tile_width * TILE_SCALING * 5)
        self.enemy_list = arc.SpriteList()
        self.enemy_list.append(self.hound1)
        self.scene.add_sprite(LAYER_NAME_ENEMY, self.hound1)

        # Play sounds so game doesnt lag when played (idk why this happens)
        self.gem_collect.play(0)
        self.hound_death.play(0)

        # timer type thing
        self.timer = 0

        # knockback
        self.kbdirection = 0

        # map settings
        self.map_width = GRID_PIXEL_SIZE*120
        self.map_height = GRID_PIXEL_SIZE*20

        # Create the 'physics engine'
        self.physics_engine = arc.PhysicsEnginePlatformer(
                self.player_sprite,
                gravity_constant=GRAVITY,
                walls=(self.scene[LAYER_NAME_TERRAIN], self.scene[LAYER_NAME_PLATFORMS])
        )
