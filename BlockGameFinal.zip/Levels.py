# Corey Verkouteren
# Levels for BlockGameCorey
# Corey Verkouteren
# 2/11/22 -
# Testing out features

import pygame as pg
import pygame.freetype
import random as rd
import DatabaseStuff
from pygame.locals import *
from os import walk

pg.init()
pg.freetype.init()

# Notes: Collision system somewhat unorthodox, created myself, and thus went through many renditions which left
# the floor as it's own collision, if reused it will be fixed


class Player(pg.sprite.Sprite):
    jumpvelocity = -8.4
    gravity = 1
    airtime = 0
    collcount = 0
    xmovement = 0
    ymovement = 0
    score = 0
    lives = 4
    jump = False
    collided = False
    dead = False

    def __init__(self, spriteimage):
        super(Player, self).__init__()
        self.animationpace = 0
        self.framecount = 0
        self.deathframe = 0
        self.damage3 = import_folder("Images/BlockCharacter/3 Damage")
        self.damage2 = import_folder("Images/BlockCharacter/2 Damage")
        self.damage1 = import_folder("Images/BlockCharacter/1 Damage")
        self.damage0 = import_folder("Images/BlockCharacter/No Damage")
        self.surf = pg.image.load(spriteimage)
        self.rect = self.surf.get_rect(center=(
            (SCREEN_WIDTH/2, SCREEN_HEIGHT/2)
        ))
        self.curpower = False
        self.poweruptimer = 0

    def loselife(self):
        self.lives -= 1

    def setcollision(self, yn):
        self.collided = yn

    # obstacle collisions, inspired by Mr.Ball's version
    def collisioncheck(self, collrect):
        if pg.Rect.colliderect(self.rect, collrect):
            # bottom side collision
            if (self.rect.bottom - self.ymovement) <= collrect.top:
                player.rect.bottom = collrect.top
                self.jump = False
                self.ymovement = 0
                self.collcount = 0
            # right side collision
            elif self.rect.right >= collrect.left > player.rect.left and self.rect.bottom > collrect.top:
                player.rect.right = collrect.left
            # left side collision
            elif self.rect.left <= collrect.right < player.rect.right and self.rect.bottom > collrect.top:
                player.rect.left = collrect.right

    def deathanimation(self):
        animation = import_folder("Images/BlockCharacter/Death1")
        if self.animationpace <= pg.time.get_ticks():
            if self.deathframe > len(animation) - 1:
                return "Game Over"
            if self.deathframe == 0:
                player.rect.move_ip((-30, -30))
            self.surf = animation[self.deathframe]
            self.deathframe += 1
            self.animationpace = pg.time.get_ticks() + 200

    def powerUpHit(self, powerup):
        if powerup == "invincible":
            self.curpower = "invincible"
            self.poweruptimer = pg.time.get_ticks() + 5200
        if powerup == "shooter":
            self.curpower = "shooter"
            self.poweruptimer = pg.time.get_ticks() + 8000
            pass

    def getPowerLeft(self):
        left = round((self.poweruptimer - pg.time.get_ticks())/120)
        if left <= 0:
            return False
        return left

    def reset(self):
        self.xmovement = 0
        self.ymovement = 0
        self.collcount = 0
        self.jump = False
        self.collided = False
        self.dead = False
        self.lives = 4
        self.airtime = 0
        self.deathframe = 0
        self.score = 0
        self.curpower = False
        self.poweruptimer = 0
        self.rect = self.surf.get_rect(center=(SCREEN_WIDTH/2, 0))

    def update(self, keypress):
        self.ymovement = 0
        self.xmovement = 0
        # floor collision
        if self.collided:
            self.jump = False
            self.ymovement = 0
            self.collcount = 0
        elif not self.collided:
            if self.collcount < 1:
                # for gravity calculations, need time been in air
                self.airtime = pg.time.get_ticks()
            # adds gravity if player not on ground
            self.ymovement += self.gravity*((pg.time.get_ticks() - self.airtime)/60)
            self.collcount += 1

        # disables powerup after timer runs out
        if self.curpower == "invincible" or self.curpower == "shooter":
            if self.poweruptimer <= pg.time.get_ticks():
                self.curpower = False

        # jump
        if keypress[K_w]:
            self.jump = True
        if self.jump:
            self.ymovement += self.jumpvelocity

        # horizontal movement
        if keypress[K_d]:
            self.xmovement += 3
        if keypress[K_a]:
            self.xmovement -= 3

        # final movement
        self.rect.move_ip(self.xmovement, self.ymovement)

        # keeps player on screen
        if self.rect.right <= 0:
            player.dead = True
        if self.rect.left >= SCREEN_WIDTH:
            player.dead = True
        if self.rect.top <= 0:
            self.rect.top = 0
        if self.rect.bottom >= SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

        if self.lives == 0:
            player.dead = True

        # animation
        if not player.dead:
            if self.lives == 4:
                if self.animationpace <= pg.time.get_ticks():
                    if self.framecount > len(self.damage0) - 1:
                        self.framecount = 0
                    self.surf = self.damage0[self.framecount]
                    self.framecount += 1
                    self.animationpace = pg.time.get_ticks() + 200
            if self.lives == 3:
                if self.animationpace <= pg.time.get_ticks():
                    if self.framecount > len(self.damage1) - 1:
                        self.framecount = 0
                    self.surf = self.damage1[self.framecount]
                    self.framecount += 1
                    self.animationpace = pg.time.get_ticks() + 200
            if self.lives == 2:
                if self.animationpace <= pg.time.get_ticks():
                    if self.framecount > len(self.damage2) - 1:
                        self.framecount = 0
                    self.surf = self.damage2[self.framecount]
                    self.framecount += 1
                    self.animationpace = pg.time.get_ticks() + 200
            if self.lives == 1:
                if self.animationpace <= pg.time.get_ticks():
                    if self.framecount > len(self.damage3) - 1:
                        self.framecount = 0
                    self.surf = self.damage3[self.framecount]
                    self.framecount += 1
                    self.animationpace = pg.time.get_ticks() + 200
            # updates rect based on size change
            self.rect.update(self.rect.left, self.rect.top, self.surf.get_width(), self.surf.get_height())


class Obstacle(pg.sprite.Sprite):
    def __init__(self, size, location, mtype):
        super(Obstacle, self).__init__()
        self.type = mtype
        self.xmovement = 0
        self.ymovement = 0
        self.surf = pg.surface.Surface(size).convert_alpha()
        self.rect = self.surf.get_rect(center=location)
        if mtype == "kill":
            self.surf.fill(orange)
        else:
            self.surf.fill(white)

    def movementpath(self):
        if self.type == "floor" or self.type == "still":
            pass
        elif self.type == "left" or self.type == "kill":
            self.xmovement = -5
            if self.rect.right <= 0:
                try:
                    obstacle_rects.remove(self.rect)
                # no idea why this bug happens, but somehow the obstacle rect list becomes longer than the obstacle list
                # itself, in future will just store all in one list and call rects. Basically this just removes the
                # rectangle
                except ValueError:
                    obstaclelist = obstacle_sprites.sprites()
                    selfindex = obstaclelist.index(self)
                    obstacle_rects.pop(selfindex)
                self.kill()
        elif self.type == "bounce":
            if self.rect.left <= 0:
                self.xmovement *= -1
            if self.rect.right >= SCREEN_WIDTH:
                self.xmovement *= -1

    def update(self):
        self.rect.move_ip(self.xmovement, self.ymovement)


class powerUp(pg.sprite.Sprite):
    def __init__(self, ptype, location):
        super(powerUp, self).__init__()
        self.type = ptype
        self.sprites = {"invincible": import_folder("Images/Powerups/invincible"),
                        "shooter": import_folder("Images/Powerups/shooter")}
        self.surf = self.sprites[self.type][0]
        self.rect = self.surf.get_rect(center=location)

        self.framecount = 0
        self.animationpace = 0

        self.rotatea = 0

    def getType(self):
        return self.type

    def update(self):
        if self.animationpace <= pg.time.get_ticks():
            if self.framecount > len(self.sprites[self.type]) - 1:
                self.framecount = 0
            self.surf = self.sprites[self.type][self.framecount]
            self.framecount += 1
            self.animationpace = pg.time.get_ticks() + 50

            # rotation
            self.rotatea += 10
            self.surf = pg.transform.rotate(self.surf, self.rotatea)
            # rotation shift fix from jdi: https://stackoverflow.com/questions/10645566/weird-shifting-when-using-pygame-transform-rotate
            self.rect = self.surf.get_rect(center=self.rect.center)

        self.rect.move_ip(-5, 0)
        if self.rect.right <= 0:
            self.kill()


class weapon(pg.sprite.Sprite):
    def __init__(self):
        super(weapon, self).__init__()
        self.weaponcount = 0
        self.xmovement = 5
        self.surf = pg.surface.Surface((35, 20)).convert_alpha()
        self.rect = self.surf.get_rect(
            center=(
                player.rect.centerx + self.surf.get_width()/2,
                (player.rect.centery - self.surf.get_height()/2)
            ))
        self.surf.fill(lightblue)

    def update(self):
        self.rect.move_ip(self.xmovement, 0)
        if self.rect.left >= SCREEN_WIDTH:
            self.kill()


def resetGame():
    player.reset()
    for entity in obstacle_sprites:
        entity.kill()
    for entity in weapon_sprites:
        entity.kill()
    for entity in powerUp_sprites:
        entity.kill()
    weapon_rects.clear()
    powerUp_rects.clear()
    obstacle_rects.clear()


# from JrtiGameSupport
def import_folder(path):
    surface_list = []
    for _, __, image_files in walk(path):
        for image in image_files:
            full_path = path + "/" + image
            image_surf = pg.image.load(full_path).convert_alpha()
            surface_list.append(image_surf)

    return surface_list


SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
running = True

clock = pg.time.Clock()
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pg.display.set_caption("Block Jumper")
white = (255, 255, 255)
red = (200, 0, 0)
black = (0, 0, 0)
blue = (0, 0, 200)
orange = (255, 100, 50)
yellow = (255, 223, 0)
green = (0, 179, 0)
lightblue = (50, 120, 255)

player = Player("Images/blockcharacter2.png")

scorefont = pg.freetype.Font("Other/Azonix-1VB0.otf", 40)
powerupfont = pg.freetype.Font("Other/Azonix-1VB0.otf", 60)

obstacle_rects = []
obstacle_sprites = pg.sprite.Group()

powerUp_rects = []
powerUp_sprites = pg.sprite.Group()

weapon_rects = []
weapon_sprites = pg.sprite.Group()

# Main Game Stuff
# not in function because it duplicates USEREVENTs
floor = Obstacle((800, 100), (SCREEN_WIDTH / 2, 600), "floor")

ADDOBSTACLE = pg.USEREVENT + 1
pg.time.set_timer(ADDOBSTACLE, 1500)
ADDPOWERUP = pg.USEREVENT + 2
pg.time.set_timer(ADDPOWERUP, 1500)


def MainGame(username):
    obstacleoptions = [(100, 50), (100, 50), (50, 50), (50, 70), (50, 100)]
    killobstacleoptions = [(50, 50), (50, 75), (75, 25)]
    positionchoices = {"y": [480, 500, 400], "x": [200, 300, 400]}

    powerupoptions = ["invincible", "shooter"]
    weaponcool = 500
    highscore = DatabaseStuff.getStats(username)
    for entity in obstacle_sprites:
        obstacle_rects.append(entity.rect)

    while running:
        player.score += 1/60
        for event in pg.event.get():
            if event.type == pg.QUIT:
                if DatabaseStuff.getStats(username) < round(player.score):
                    DatabaseStuff.saveGameStats(username, round(player.score))
                return False

            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    return False

                if event.key == K_SPACE:
                    if player.curpower == "shooter":
                        if weaponcool <= pg.time.get_ticks():
                            newweapon = weapon()
                            weapon_sprites.add(newweapon)
                            weapon_rects.append(newweapon)
                            weaponcool = pg.time.get_ticks() + 500

            if event.type == ADDOBSTACLE:
                newobstacle = Obstacle(rd.choice(obstacleoptions), (SCREEN_WIDTH + 50, 510), "left")
                obstacle_sprites.add(newobstacle)
                obstacle_rects.append(newobstacle.rect)
                newkillobstacle = Obstacle(rd.choice(killobstacleoptions), (SCREEN_WIDTH + rd.choice(positionchoices["x"]),
                                                                            rd.choice(positionchoices["y"])), "kill")
                obstacle_sprites.add(newkillobstacle)
                obstacle_rects.append(newkillobstacle.rect)

            if event.type == ADDPOWERUP:
                if rd.randint(0, 8) == 1:
                    newpowerup = powerUp(rd.choice(powerupoptions), (SCREEN_WIDTH + 50, 350))
                    powerUp_sprites.add(newpowerup)
                    powerUp_rects.append(newpowerup.rect)

        if player.dead:
            if player.deathanimation() == "Game Over":
                if DatabaseStuff.getStats(username) < round(player.score):
                    DatabaseStuff.saveGameStats(username, round(player.score))
                return "Game Over", username

        # Updates

        if not player.dead:
            pressed_keys = pg.key.get_pressed()
            player.update(pressed_keys)

        pg.draw.rect(screen, blue, screen.get_rect())

        # non-player sprite/rect updates (also collisions)
        if not player.dead:
            # powerup collision/updates
            for entity in powerUp_sprites:
                entity.update()
                if pg.Rect.colliderect(entity.rect, player.rect):
                    entity.kill()
                    player.powerUpHit(entity.getType())
            # weapon collision/updates
            for entity in weapon_sprites:
                entity.update()
                # if weapon hits an obstacle, destroy both and give 5 points
                for e in obstacle_sprites:
                    if pg.Rect.colliderect(e.rect, entity.rect):
                        e.kill()
                        entity.kill()
                        weapon_rects.remove(entity.rect)
                        obstacle_rects.remove(e.rect)
                        player.score += 5
            # obstacle collision/updates
            for entity in obstacle_sprites:
                entity.movementpath()
                entity.update()
                if entity.type == "kill":
                    if pg.Rect.colliderect(entity.rect, player.rect):
                        if player.curpower != "invincible":
                            player.loselife()
                        if player.curpower == "invincible":
                            player.score += 5
                        obstacle_rects.remove(entity.rect)
                        entity.kill()
                    if len(pg.Rect.collidelistall(entity.rect, obstacle_rects)) > 1:
                        obstacle_rects.remove(entity.rect)
                        entity.kill()
                player.collisioncheck(entity.rect)

        # floor collision
        if pg.Rect.colliderect(player.rect, floor):
            player.rect.bottom = floor.rect.top
            player.setcollision(True)
        else:
            player.setcollision(False)

        for entity in obstacle_sprites:
            screen.blit(entity.surf, entity.rect)

        for entity in powerUp_sprites:
            screen.blit(entity.surf, entity.rect)

        for entity in weapon_sprites:
            screen.blit(entity.surf, entity.rect)

        screen.blit(floor.surf, floor.rect)

        screen.blit(player.surf, player.rect)

        # score
        score, scorerect = scorefont.render(f"{round(player.score)}")
        screen.blit(score, (20, 60))
        # high score
        if round(player.score) > highscore:
            highscore = round(player.score)
        hsscore, hsrect = scorefont.render(str(highscore), yellow)
        screen.blit(hsscore, (20, 20))
        # powerup info
        if player.getPowerLeft():
            timecolor = green
            if player.getPowerLeft() <= 30:
                timecolor = yellow
            if player.getPowerLeft() <= 20:
                timecolor = orange
            if player.getPowerLeft() <= 10:
                timecolor = red
            powertext, powerect = powerupfont.render(f"{player.curpower}", fgcolor=white)
            timetext, timerect = powerupfont.render(f"{player.getPowerLeft()}", fgcolor=timecolor)
            screen.blit(powertext, (SCREEN_WIDTH/2 - 240, 120))
            screen.blit(timetext, (SCREEN_WIDTH/2 + 150, 120))
        pg.display.flip()
        clock.tick(60)


def Testing(username):
    highscore = DatabaseStuff.getStats(username)
    ob1 = Obstacle((50, 50), (300, 500), "still")
    obstacle_sprites.add(ob1)
    obstacle_rects.append(ob1)

    obstacleoptions = [(100, 50), (100, 50), (50, 50), (50, 70), (50, 100)]
    killobstacleoptions = [(50, 50), (50, 75), (75, 25)]
    positionchoices = {"y": [480, 500, 400], "x": [200, 300, 400]}

    powerupoptions = ["invincible", "shooter"]
    weaponcool = 500
    highscore = DatabaseStuff.getStats(username)

    for entity in obstacle_sprites:
        obstacle_rects.append(entity.rect)

    while running:
        player.score += 1/60
        for event in pg.event.get():
            if event.type == pg.QUIT:
                if DatabaseStuff.getStats(username) < round(player.score):
                    DatabaseStuff.saveGameStats(username, round(player.score))
                return False

            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    return False

                if event.key == K_r:
                    newpowerup = powerUp(rd.choice(powerupoptions), (SCREEN_WIDTH, 350))
                    powerUp_sprites.add(newpowerup)
                    powerUp_rects.append(newpowerup.rect)


                if event.key == K_SPACE:
                    if player.curpower == "shooter":
                        if weaponcool <= pg.time.get_ticks():
                            newweapon = weapon()
                            weapon_sprites.add(newweapon)
                            weapon_rects.append(newweapon)
                            weaponcool = pg.time.get_ticks() + 500

                if event.key == K_f:
                    newobstacle = Obstacle(rd.choice(obstacleoptions), (SCREEN_WIDTH + 50, 510), "left")
                    obstacle_sprites.add(newobstacle)
                    obstacle_rects.append(newobstacle.rect)
                    newkillobstacle = Obstacle(rd.choice(killobstacleoptions), (SCREEN_WIDTH + rd.choice(positionchoices["x"]),
                                                                                rd.choice(positionchoices["y"])), "kill")
                    obstacle_sprites.add(newkillobstacle)
                    obstacle_rects.append(newkillobstacle.rect)

        if player.dead:
            if player.deathanimation() == "Game Over":
                if DatabaseStuff.getStats(username) < round(player.score):
                    DatabaseStuff.saveGameStats(username, round(player.score))
                return "Game Over", username

        # Updates

        if not player.dead:
            pressed_keys = pg.key.get_pressed()
            player.update(pressed_keys)

        pg.draw.rect(screen, blue, screen.get_rect())

        if not player.dead:
            for entity in powerUp_sprites:
                entity.update()
                if pg.Rect.colliderect(entity.rect, player.rect):
                    entity.kill()
                    player.powerUpHit(entity.getType())
            for entity in weapon_sprites:
                entity.update()
                # if weapon hits an obstacle, destroy both and give 5 points
                for e in obstacle_sprites:
                    if pg.Rect.colliderect(e.rect, entity.rect):
                        e.kill()
                        entity.kill()
                        weapon_rects.remove(entity.rect)
                        obstacle_rects.remove(e.rect)
                        player.score += 5
            for entity in obstacle_sprites:
                entity.movementpath()
                entity.update()
                if entity.type == "kill":
                    if pg.Rect.colliderect(entity.rect, player.rect):
                        if player.curpower != "invincible":
                            player.loselife()
                        obstacle_rects.remove(entity.rect)
                        entity.kill()
                    if len(pg.Rect.collidelistall(entity.rect, obstacle_rects)) > 1:
                        obstacle_rects.remove(entity.rect)
                        entity.kill()
                player.collisioncheck(entity.rect)

        # floor collision
        if pg.Rect.colliderect(player.rect, floor):
            player.rect.bottom = floor.rect.top
            player.setcollision(True)
        else:
            player.setcollision(False)

        for entity in obstacle_sprites:
            screen.blit(entity.surf, entity.rect)

        for entity in powerUp_sprites:
            screen.blit(entity.surf, entity.rect)

        for entity in weapon_sprites:
            screen.blit(entity.surf, entity.rect)

        screen.blit(floor.surf, floor.rect)

        screen.blit(player.surf, player.rect)

        # score
        score, scorerect = scorefont.render(f"{round(player.score)}")
        screen.blit(score, (20, 60))
        # high score
        if round(player.score) > highscore:
            highscore = round(player.score)
        hsscore, hsrect = scorefont.render(str(highscore), yellow)
        screen.blit(hsscore, (20, 20))
        # powerup info
        if player.getPowerLeft():
            timecolor = green
            if player.getPowerLeft() <= 30:
                timecolor = yellow
            if player.getPowerLeft() <= 20:
                timecolor = orange
            if player.getPowerLeft() <= 10:
                timecolor = red
            powertext, powerect = powerupfont.render(f"{player.curpower}", fgcolor=white)
            timetext, timerect = powerupfont.render(f"{player.getPowerLeft()}", fgcolor=timecolor)
            screen.blit(powertext, (SCREEN_WIDTH/2 - 240, 120))
            screen.blit(timetext, (SCREEN_WIDTH/2 + 150, 120))

        pg.display.flip()
        clock.tick(60)
