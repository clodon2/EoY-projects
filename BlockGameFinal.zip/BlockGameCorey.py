# Corey Verkouteren
# Mr.Ball's PM Class
# 2/11/22 - 2/28/22
# 2nd Game, practice in pygame. first platformer-like for me

import Menus
import Levels
import DatabaseStuff as db


# Block Jumper

running = True
inmenu = True
intutorial = False
inmaingame = False
gameover = False

while running:
    while inmenu:
        menuresult = Menus.MainMenu()
        if not menuresult:
            running = False
            inmenu = False
        elif menuresult[0] == "Start Game":
            inmaingame = True
            inmenu = False
    while inmaingame:
        gameresult = Levels.MainGame(menuresult[1])
        if not gameresult:
            running = False
            inmaingame = False
        elif gameresult[0] == "Game Over":
            gameover = True
            inmaingame = False
    while gameover:
        menuresult = Menus.GameOver(gameresult[1])
        if not menuresult:
            running = False
            gameover = False
        elif menuresult[0] == "Retry":
            Levels.resetGame()
            inmaingame = True
            gameover = False
        elif menuresult[0] == "Main Menu":
            Levels.resetGame()
            inmenu = True
            gameover = False
