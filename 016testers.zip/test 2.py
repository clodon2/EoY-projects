# Module Assignment

import PySimpleGUI as sg
import test1 as ml




dValues = ['Subdued/Professional','Slightly Out there','Wild and Crazy']
layout = [[sg.Text("Lend me your Module",justification='center',size=(800,4),key="Title",
                   font = ("Ariel",30),text_color="black")],
          [sg.Text("Enter Your name: "),sg.InputText("",size= (15,1),key=("name")),
            sg.Button("Convert",key="convertName"),
            sg.Text("Your name Value"),sg.InputText("",size=(10,1),key="nameTotal")],
          [sg.Radio("Not Transparent",group_id="S1",key="nt",enable_events=True,default=True),
           sg.Radio("Slightly Transparent",group_id="S1",key="st",enable_events=True),
           sg.Radio("Very Transparent",group_id="S1",key="vt",enable_events=True)],
          [sg.Text("Color Theme"),sg.Combo(dValues,key='color',enable_events=True)]]

window = sg.Window("Module Assignment",layout=layout,size=(800,400))

while True:
    event,values = window.read()
    if event == sg.WINDOW_CLOSED or event == "Exit":
        break
    elif event == "convertName":
        eName = window["name"].get()
        totalName = ml.addupname(eName)
        window["nameTotal"].update(totalName)
    elif event == "st" or event== "vt" or event == "nt":
        alpha = ml.setAlpha(event)
        window.alpha_channel = alpha
    elif event == "color":
        cTheme = ml.setColor(values["color"])
        print(cTheme)
        print(event,values)
        window["Title"].update(text_color=cTheme)
    else:
        print(event,values)
