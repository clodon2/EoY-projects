# Corey Verkouteren
# 12/9/21 - 2/7/22
# Mr Ball's PM
# PyGame Introduction

# Virus Avoider
import sqlite3 as sq
from sqlite3 import Error
import pygame as pg
import pygame.freetype
import random as rd
from pygame.locals import *
from os import walk


# from JrtiGameSupport, wouldn't recognize as an import for me
def import_folder(path):
    surface_list = []
    for _, __, image_files in walk(path):
        for image in image_files:
            full_path = path + "/" + image
            image_surf = pg.image.load(full_path).convert_alpha()
            surface_list.append(image_surf)

    return surface_list


# Database functions


# connects to database
def dbConnection():
    conn = None
    try:
        conn = sq.connect("GameStats.db")
    except Error as e:
        print(e)

    return conn


# inserts player as a new row for database if they aren't in it already
def insertPlayer(user):
    try:
        conn = dbConnection()
        curr = conn.cursor()
        # separate values to avoid "injection" attacks, unnecessary here but a good habit
        insert = f"INSERT INTO Stats VALUES (?, ?)"
        curr.execute(insert, (user, 0))
        conn.commit()
        conn.close()
    except sq.IntegrityError:
        pass


# updates the user's stats
def saveGameStats(user, highscore):
    conn = dbConnection()
    curr = conn.cursor()
    updateSQL = f"UPDATE Stats set Highscore = ? WHERE UserID = ?"
    record = (highscore, user)
    curr.execute(updateSQL, record)
    conn.commit()
    conn.close()


# grabs top ten players by score
def getLeaderboard():
    conn = dbConnection()
    top10 = []
    cursor = conn.execute("SELECT * FROM Stats ORDER BY Highscore DESC")
    for row in cursor:
        top10.append(row)
    conn.close()
    return top10[:10]


# returns highscore of the user
def getStats(user):
    conn = dbConnection()
    cursor = conn.execute(f"SELECT Highscore FROM Stats WHERE UserID = ?", [user])
    for row in cursor:
        # fixes bug in closing from menu where database checks for a user that doesn't exist, thus there is no result
        if row[0] is None:
            return 0
        else:
            return row[0]
    conn.close()


# game classes


class Virus(pg.sprite.Sprite):
    def __init__(self):
        super(Virus, self).__init__()
        # explosion sprites from
        # https://www.pngjoy.com/preview/t0p4x7m5b4z4j2_explosion-unity-sprite-sheet-explosion-png-download/ ,
        # some small modifications done
        self.explosionani = import_folder("Images/explosion/")
        self.explosionframecount = 0
        self.animationpace = 0
        # Virus image I made myself
        virusimage = pg.transform.scale(pg.image.load("images/ViruswindowimageCorey.png").convert_alpha(), (170, 47))
        self.surf = virusimage
        self.rect = self.surf.get_rect(
            center=(
                    (rd.randint(80, SCREEN_WIDTH - 80)),
                    (rd.randint(5, 10)),
                    ))
        self.speed = rd.randint(2, 10)
        self.dead = False

    def update(self):
        if self.dead:
            # slows down the animation a little so it lasts longer
            if self.animationpace <= pg.time.get_ticks():
                # plays explosion animation until out of frames
                if self.explosionframecount > len(self.explosionani) - 1:
                    self.kill()
                else:
                    if self.explosionframecount == 0:
                        # moves animation over so that it is closer to the middle of the original virus image
                        self.rect.move_ip(-60, -100)
                    self.surf = pg.transform.scale(self.explosionani[self.explosionframecount], (300, 300))
                    self.explosionframecount += 1
                # resets cooldown until next frame
                self.animationpace = pg.time.get_ticks() + 30
        else:
            # moves virus and kills once it is past the taskbar image
            self.rect.move_ip(0, self.speed)
            if self.rect.top >= SCREEN_HEIGHT - 39:
                self.kill()


class Player(pg.sprite.Sprite):
    isMoving = False
    speed = 5
    corruption = 0
    score = 0

    def setMoving(self, value):
        self.isMoving = value

    def increaseScore(self, increase):
        self.score += increase

    def increaseSpeed(self, increase):
        self.speed += increase

    def loseLife(self):
        self.corruption += 25

    def __init__(self, spriteimage):
        super(Player, self).__init__()
        self.hitHighscore = False
        self.finalsprite = pg.transform.scale(pg.image.load(spriteimage).convert_alpha(), [50, 64])
        # original sprite plus effects from https://photomosh.com/
        self.life3 = import_folder("Images/cursor glitch1")
        self.life2 = import_folder("Images/cursor glitch2/")
        self.life1 = import_folder("Images/cursor glitch3/")
        self.framecount = 0
        self.animationpace = 0
        self.surf = self.finalsprite
        self.rect = self.surf.get_rect(
            center=(
                    (SCREEN_WIDTH / 2),
                    (SCREEN_HEIGHT - 89),
                    ))

    def update(self, keypress):
        # moves according to button press
        if keypress[K_LEFT]:
            self.rect.move_ip(-self.speed, 0)
        if keypress[K_RIGHT]:
            self.rect.move_ip(self.speed, 0)
        # keeps player on screen
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top <= 0:
            self.rect.top = 0
        if self.rect.bottom >= SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

        # updates sprite to reflect amount of damage taken, under 100 hp sprites are animated
        if self.corruption == 0:
            self.surf = self.finalsprite
        if self.corruption == 25:
            if self.animationpace <= pg.time.get_ticks():
                if self.framecount > len(self.life2) - 1:
                    self.framecount = 0
                self.surf = pg.transform.scale(self.life3[self.framecount], (50, 64))
                self.framecount += 1
                self.animationpace = pg.time.get_ticks() + 200
        if self.corruption == 50:
            if self.animationpace <= pg.time.get_ticks():
                if self.framecount > len(self.life2) - 1:
                    self.framecount = 0
                self.surf = pg.transform.scale(self.life2[self.framecount], (50, 64))
                self.framecount += 1
                self.animationpace = pg.time.get_ticks() + 200
        if self.corruption == 75:
            if self.animationpace <= pg.time.get_ticks():
                if self.framecount > len(self.life2) - 1:
                    self.framecount = 0
                self.surf = pg.transform.scale(self.life1[self.framecount], (50, 64))
                self.framecount += 1
                self.animationpace = pg.time.get_ticks() + 200


    def reset(self):
        self.rect.update(SCREEN_WIDTH/2 - 25, SCREEN_HEIGHT - 120, 50, 64)
        self.corruption = 0
        self.speed = 5
        self.score = 0
        self.hitHighscore = False


class Weapon(pg.sprite.Sprite):
    def __init__(self):
        wtype = rd.choice(["rocket"])
        self.rocketcount = 0
        self.animationpace = 200
        self.wtype = wtype
        self.speed = 0
        super(Weapon, self).__init__()
        if wtype == "rocket":
            self.surf = pg.image.load("Images/rocketweapon/weaponrocket1.png").convert_alpha()
        self.rect = self.surf.get_rect(
            center=(
                player.rect.centerx,
                (player.rect.centery - self.surf.get_height()/2)
            ))

    def update(self):
        # all rocket sprites are my own
        rocketani = import_folder("Images/rocketweapon/")
        # increases the time between sprite changes
        if self.animationpace <= pg.time.get_ticks():
            if self.wtype == "rocket":
                if self.rocketcount > len(rocketani) - 1:
                    self.rocketcount = 3
                self.surf = rocketani[self.rocketcount].convert_alpha()
                self.rocketcount += 1
                # increases speed exponentially, like a real rocket
                self.speed *= 1.3
                self.speed += 1
            self.animationpace = pg.time.get_ticks() + 200
        else:
            pass

        if self.rect.bottom <= 0:
            rocketthrust.fadeout(400)
            self.kill()
        else:
            self.rect.move_ip(0, -self.speed)


# menu/text classes


class MenuButton(pg.sprite.Sprite):
    def __init__(self, button, location):
        super(MenuButton, self).__init__()
        self.surf = pg.image.load(button).convert_alpha()
        self.rect = self.surf.get_rect(
            center=(
                    location,
                    ))

    def clicked(self):
        return False


class GameOverButton(pg.sprite.Sprite):
    def __init__(self, button, location):
        super(GameOverButton, self).__init__()
        self.surf = pg.image.load(button).convert_alpha()
        self.rect = self.surf.get_rect(
            center=(
                    (SCREEN_WIDTH/2),
                    location,
                    ))


class HUDtext:
    def __init__(self, text, location, color, style):
        self.text = text
        self.location = location
        self.color = color
        self.style = style
        self.animationpace = 0
        self.framecount = 0

    def render(self):
        return gamefont.render(self.text, self.color, style=self.style)

    def rendersmall(self):
        return smallgamefont.render(self.text, self.color, style=self.style)

    def locationchange(self, location):
        self.location = location

    def textchange(self, text):
        self.text = text

    def colorchange(self, color):
        self.color = color

    def stylechange(self, style):
        self.style = style

    def lowAnimation(self):
        if self.animationpace <= pg.time.get_ticks():
            if self.framecount > 1:
                self.framecount = 0
            if self.framecount == 0:
                self.color = red
            elif self.framecount == 1:
                self.color = white
            self.framecount += 1
            self.animationpace = pg.time.get_ticks() + 200


# menu functions

# generates the nameplates/surfaces for leaderboard
class leaderNames(pg.sprite.Sprite):
    def __init__(self, leader):
        super(leaderNames, self).__init__()
        self.name = leader[0]
        self.highscore = leader[1]
        self.surf = pg.Surface((450, 50))
        self.rect = self.surf.get_rect(
            center=(300, 100)
        )
        self.surf.fill((20, 20, 20))
        self.scoresurf = gamefont.render(f"{leader[1]}")[0]

        # renders leader name and score onto the blank rectangle
        gamefont.render_to(self.surf, (5, 10), f"{leader[0]}", white)
        # calculates score text position so that it is aligned to the right
        scoreXvalue = self.surf.get_width() - self.scoresurf.get_width() - 5
        gamefont.render_to(self.surf, (scoreXvalue, 10), f"{leader[1]}", white)


# leaderboard display, may switch the other menus over to functions later
def Leaderboard(leaders):
    inLeaderboard = True
    leadercount = 0
    leader_sprites = pg.sprite.Group()
    # creates and blits the leaderboard names and scores
    for l in leaders:
        classname = leaderNames(l)
        # spaces out leaderboard names evenly based on position
        classname.rect.move_ip(0, leadercount*67)
        screen.blit(classname.surf, classname.rect)
        leader_sprites.add(classname)
        leadercount += 1
    # closing button
    closer = pg.transform.scale(pg.image.load("Images/closebutton.png"), (50, 50))
    closerrect = closer.get_rect(center=(550, 50))
    while inLeaderboard:
        for event in pg.event.get():
            # detects closing button press
            if pg.mouse.get_pressed(num_buttons=3)[0]:
                if pg.Rect.collidepoint(closerrect, pg.mouse.get_pos()):
                    return False

            if event.type == pg.QUIT:
                return True

            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    return False

        # background surface
        lbackground = pg.Surface((500, 700))
        lbackground.fill((50, 50, 50))
        screen.blit(lbackground, (50, 50))

        for entity in leader_sprites:
            screen.blit(entity.surf, entity.rect)

        screen.blit(closer, closerrect)

        pg.display.flip()
        clock.tick(30)


# pause menu, can only be activated while in game
def pause():
    paused = True
    resume = MenuButton("Images/resumebutton.png", (300, 300))
    backtomenu = MenuButton("Images/backtomenu.png", (300, 500))
    pausetext, ptrect = gamefont.render("Paused", white)

    # dims screen before pause, inspired by https://stackoverflow.com/questions/38931142/pygame-how-to-darken-screen
    pausebg = screen.convert_alpha()
    pausebg.fill((0, 0, 0, 90))
    screen.blit(pausebg, (0, 0))

    while paused:
        # for returns, False = close pause menu, True: close game, menu = back to menu screen
        for event in pg.event.get():
            # detects button presses
            if pg.mouse.get_pressed(num_buttons=3)[0]:
                if pg.Rect.collidepoint(resume.rect, pg.mouse.get_pos()):
                    return False
                if pg.Rect.collidepoint(backtomenu.rect, pg.mouse.get_pos()):
                    return "menu"
            if event.type == pg.QUIT:
                return True
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    return False

        screen.blit(resume.surf, resume.rect)
        screen.blit(backtomenu.surf, backtomenu.rect)
        screen.blit(pausetext, (300 - pausetext.get_width()/2, 150))

        pg.display.flip()
        clock.tick(30)


# initialize
pg.init()
pg.font.init()
pg.mixer.init()

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 800

# setup for essential things like font, fps, screen, and window title
gamefont = pg.freetype.Font("other/Segoe UI.ttf", 40)
smallgamefont = pg.freetype.Font("other/Segoe UI.ttf", 30)
clock = pg.time.Clock()
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pg.display.set_caption("Virus Avoider")
white = (255, 255, 255)
black = (0, 0, 0)
yellow = (255, 230, 0)
orange = (255, 120, 0)
red = (200, 0, 0)

# Menu Stuff
menubackground = pg.image.load("Images/mountainriver.png").convert_alpha()
# Photo by Roberto Nickson from Pexels
startbutton = MenuButton("Images/startbutton.png", (450, 450))
leaderboardbutton = MenuButton("Images/lbutton.png", (SCREEN_WIDTH/2, 600))
username = "Name Here [type]"
inputbackground = pg.transform.scale(pg.image.load("Images/whiteblock.png"), (300, 35))
inputbackgroundrect = inputbackground.get_rect(center=(SCREEN_WIDTH/2 - 50, 450))
loginpicture = pg.image.load("Images/loginpicture.png")
# screenshot of login thing
usertitletext = HUDtext("Administrator", (200, 370), white, 1)
validcharacters = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM _-1234567890"

# Sounds
# https://www.mixkit.co/
playerHit = pg.mixer.Sound("Sounds/glitch explosion.wav")
playerDead = pg.mixer.Sound("Sounds/explosion w echo.wav")
rocketthrust = pg.mixer.Sound("Sounds/rocket thrust.wav")
highscoreHit = pg.mixer.Sound("Sounds/Achievement.wav")
# https://www.zapsplat.com/sound-effect-category/explosions/
rocketExplode = pg.mixer.Sound("Sounds/fire explosion.mp3")

rocketthrust.set_volume(.2)
playerHit.set_volume(.15)
playerDead.set_volume(.25)
highscoreHit.set_volume(.4)
rocketExplode.set_volume(.4)

# Game Stuff
player = Player("images/grab icon.png")
# <a href="https://www.vecteezy.com/free-vector/mouse-icon">Mouse Icon Vectors by Vecteezy</a>
background = pg.image.load("images/Background Image.jpg").convert_alpha()
# https://www.pexels.com/photo/scenic-view-of-snow-capped-mountains-during-night-3408744/
taskbar = pg.image.load("images/taskbar image.png").convert_alpha()
# just a screenshot of my taskbar
weaponcooldown = 0
colorchange = 0
colorcooldown = 0

# Game Over stuff
retrybutton = GameOverButton("Images/restartbutton.png", 600)
GObackground = pg.image.load("Images/windowsbluescreen.png").convert_alpha()
BackToMenubutton = GameOverButton("Images/backtomenu.png", 200)

# Text stuff
corruptiontitle = HUDtext("Corruption Levels", (0, 0), black, 0)
corruptiontext = HUDtext(f"{player.corruption}%", (0, 35), black, 0)
scoretitle = HUDtext("Score", (SCREEN_WIDTH, 0), black, 0)
scoretext = HUDtext(str(player.score), (SCREEN_WIDTH, 0), black, 0)
highscorenumber = HUDtext(str(getStats(username)), (SCREEN_WIDTH, 0), black, 0)
highscoretitle = HUDtext("Highscore", (300, 0), black, 5)

# sprite groups
#menu
menu_sprites = pg.sprite.Group()
menu_sprites.add(startbutton)
menu_sprites.add(leaderboardbutton)
#game
all_sprites = pg.sprite.Group()
weapon_sprites = pg.sprite.Group()
virus_sprites = pg.sprite.Group()
all_sprites.add(player)
#gameover
gameover_sprites = pg.sprite.Group()
gameover_sprites.add(retrybutton)
gameover_sprites.add(BackToMenubutton)

# makes an event to add a virus. runs that event every x amount
ADDVIRUS = pg.USEREVENT + 1
pg.time.set_timer(ADDVIRUS, 1000)

running = True
inmenu = True
gameover = False

while running:
    while inmenu:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                running = False
                inmenu = False

            if event.type == MOUSEBUTTONDOWN:
                # if the player left clicks the start button, the player leaves the menu
                if pg.mouse.get_pressed(num_buttons=3)[0]:
                    if pg.Rect.collidepoint(startbutton.rect, pg.mouse.get_pos()):
                        if username == "Name Here [type]" or username == "":
                            username = "Tester"
                        insertPlayer(username)
                        inmenu = False
                    # opens leaderboard, also checks if program was closed from leaderboard
                    if pg.Rect.collidepoint(leaderboardbutton.rect, pg.mouse.get_pos()):
                        if Leaderboard(getLeaderboard()):
                            running = False
                            inmenu = False

            if event.type == KEYDOWN:
                # auto-deletes instructions
                if username == "Name Here [type]":
                    username = ""
                if event.key == K_BACKSPACE:
                    # deletes the last character
                    username = username[:-1]
                elif event.key == K_RETURN:
                    if username == "Name Here [type]" or username == "":
                        username = "Tester"
                    insertPlayer(username)
                    # starts game
                    inmenu = False
                else:
                    # adds character to username
                    if event.unicode in validcharacters:
                        username += event.unicode
                # keeps username within 10 characters
                username = username[:10]


        inputtext, inputrectangle = smallgamefont.render(username, black)
        # puts text inside of the white box
        inputrectangle.clamp_ip(inputbackgroundrect)
        # adjusts text to be in the center of the background (white box)
        inputbgcenter = (inputbackgroundrect.height - inputrectangle.height)/2
        inputrectangle.move_ip(2, inputbgcenter)

        screen.blit(menubackground, (0, 0))
        screen.blit(inputbackground, inputbackgroundrect)
        screen.blit(loginpicture, (200, 150))
        screen.blit(usertitletext.rendersmall()[0], usertitletext.location)

        screen.blit(inputtext, inputrectangle)
        for entity in menu_sprites:
            screen.blit(entity.surf, entity.rect)

        pg.display.flip()
        # FPS
        clock.tick(30)


    while gameover:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                gameover = False
                running = False

            if event.type == MOUSEBUTTONDOWN:
                # detects if the user left clicks a button and responds by resetting the game and returning to a screen
                if pg.mouse.get_pressed(num_buttons=3)[0]:
                    if pg.Rect.collidepoint(retrybutton.rect, pg.mouse.get_pos()):
                        player.reset()
                        for entity in virus_sprites:
                            entity.kill()
                        gameover = False
                    if pg.Rect.collidepoint(BackToMenubutton.rect, pg.mouse.get_pos()):
                        player.reset()
                        for entity in virus_sprites:
                            entity.kill()
                            inmenu = True
                        gameover = False

        gameovertext, gameoverrect = gamefont.render("Game Over")
        # shows score
        endscore, endscorerect = gamefont.render(f"Score: {player.score}")
        # shows highscore
        endhighscore, endhsrect = gamefont.render(f"Highscore: {getStats(username)}")
        screen.blit(GObackground, (0, 0))
        screen.blit(gameovertext, (SCREEN_WIDTH - 400, 100))
        # centers scores
        screen.blit(endscore, (SCREEN_WIDTH/2 - endscorerect.width/2, 670))
        screen.blit(endhighscore, (SCREEN_WIDTH/2 - endhsrect.width/2, 730))


        for entity in gameover_sprites:
            screen.blit(entity.surf, entity.rect)

        pg.display.flip()
        clock.tick(30)


    for event in pg.event.get():
        if event.type == pg.QUIT:
            # updates user's highscore if they surpass the previous one they set
            if getStats(username) < player.score:
                saveGameStats(username, player.score)
            running = False

        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                # updates user's highscore if they surpass the previous one they set
                if getStats(username) < player.score:
                    saveGameStats(username, player.score)
                pauseresult = pause()
                if pauseresult == "menu":
                    player.reset()
                    for entity in virus_sprites:
                        entity.kill()
                    for entity in weapon_sprites:
                        entity.kill()
                    inmenu = True
                elif pauseresult:
                    running = False
            if event.key == K_LEFT or event.key == K_RIGHT:
                player.setMoving(True)

        if event.type == KEYUP:
            if event.key == K_LEFT or event.key == K_RIGHT:
                player.setMoving(False)
            if event.key == K_UP:
                # prevents spam firing, only allows a shot every couple seconds
                if weaponcooldown + 2200 <= pg.time.get_ticks():
                    rocketthrust.play()
                    weaponcooldown = pg.time.get_ticks()
                    projectile = Weapon()
                    weapon_sprites.add(projectile)
                    all_sprites.add(projectile)
                else:
                    pass
            # if user closes the window, the program turns off
            elif event.type == QUIT:
                running = False

        # adds a virus to appropriate sprite groups and instantiates it
        if event.type == ADDVIRUS:
            newvirus = Virus()
            all_sprites.add(newvirus)
            virus_sprites.add(newvirus)

    # detects collisions between player and any viruses and changes corruption accordingly
    for entity in virus_sprites:
        if pg.Rect.colliderect(player.rect, entity.rect):
            player.loseLife()
            if player.corruption <= 99:
                playerHit.play()
            entity.kill()

    virusrects = []
    for entity in virus_sprites:
        virusrects.append(entity.rect)

    # detects weapon-virus collisions, and kills both if they collide
    for entity in weapon_sprites:
        if pg.Rect.collidelistall(entity.rect, virusrects):
            hit = pg.Rect.collidelistall(entity.rect, virusrects)
            rocketthrust.stop()
            rocketExplode.play()
            entity.kill()
    try:
        for i in hit:
            virus_sprites.sprites()[i].dead = True
            player.increaseScore(100)
        hit = None
    except:
        pass

    # sends to gameover screen if the player runs out of corruption, also updates database if new highscore
    if player.corruption >= 100:
        playerDead.play()
        playerDead.fadeout(2000)
        # updates user's highscore if they surpass the previous one they set
        if getStats(username) < player.score:
            saveGameStats(username, player.score)
        gameover = True

    # all updates
    pressed_keys = pg.key.get_pressed()
    player.update(pressed_keys)
    virus_sprites.update()
    weapon_sprites.update()

    # database calls
    # updates user's highscore if they surpass the previous one they set, in try and except for some error regarding
    # closing before a username is confirmed
    try:
        if getStats(username) < player.score:
            # done so that sound only plays once
            if not player.hitHighscore:
                highscoreHit.play()
                player.hitHighscore = True
            highscorenumber.textchange(f"{player.score}")
    except TypeError:
        pass

    # HUD info updating and text
    corruptionscore, ctsize = corruptiontitle.rendersmall()
    # makes a surface of text that displays the player's amount of corruption
    corruptiontext.textchange(f"{player.corruption}%")
    corruptioncounter, ccsize = corruptiontext.render()
    # score display
    scoretitletext, stsize = scoretitle.rendersmall()
    highscoretext, hstsize = highscorenumber.render()
    highscorettitle, hsttsize = highscoretitle.rendersmall()
    scoretext.textchange(str(player.score))
    scorecounter, ssize = scoretext.render()
    highscorenumber.textchange(str(getStats(username)))

    # changes color of font based on corruption (for corruptiontext)
    if player.corruption == 0:
        corruptiontext.colorchange(black)
        corruptiontext.stylechange(0)
    elif player.corruption == 25:
        corruptiontext.colorchange(yellow)
        corruptiontext.stylechange(1)
    elif player.corruption == 50:
        corruptiontext.colorchange(orange)
        corruptiontext.stylechange(3)
    elif player.corruption == 75:
        corruptiontext.lowAnimation()
        corruptiontext.stylechange(7)

    # used for centering the text underneath corruption levels
    corruptiontext.locationchange((corruptionscore.get_rect()[2] / 2 - corruptioncounter.get_rect()[2] / 2, 35))
    # get rect allows you to see the dimensions of the text, so getting the width in this case allows that if the text
    # widens (single digit to multi-digit), it won't go off screen
    scoretext.locationchange((SCREEN_WIDTH - scorecounter.get_rect()[2], 35))
    scoretitle.locationchange((SCREEN_WIDTH - scoretitletext.get_rect()[2], 0))

    # more text centering
    highscorenumber.locationchange((300 + (hsttsize.width/2) - (hstsize.width/2), 0 + hsttsize.height + 5))

    # loads here so that it is behind all surfaces
    screen.blit(background, (0, 0))

    for entity in all_sprites:
        screen.blit(entity.surf, entity.rect)

    # renders taskbar and life counter later so that they appear above the virus images
    screen.blit(taskbar, (0, 761))

    # text rendering, currently separate because of the text system I set up (separate values to one thing, so can't
    # do the thing that I did with sprites), on list of things to improve
    screen.blit(highscoretext, highscorenumber.location)
    screen.blit(highscorettitle, highscoretitle.location)
    screen.blit(scoretitletext, scoretitle.location)
    screen.blit(corruptionscore, (0, 0))
    screen.blit(corruptioncounter, corruptiontext.location)
    screen.blit(scorecounter, scoretext.location)

    pg.display.flip()
    # FPS
    clock.tick(60)
